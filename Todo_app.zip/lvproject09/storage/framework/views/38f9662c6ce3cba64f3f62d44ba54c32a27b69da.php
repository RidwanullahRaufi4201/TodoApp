<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <title>Todos</title>
</head>
<body class="d-flex justify-content-center ">
      
<a href="<?php echo e(route('all-todos')); ?>" class="mt-5 fs-2">Todos</a>
</body>
</html><?php /**PATH C:\Users\Ridwanullah Raufi\Desktop\LaravelPractice\lvproject09\resources\views/Todo/index.blade.php ENDPATH**/ ?>