<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <title>Document</title>
    <style>
        svg{
            display:none;
        }
        div.hidden{
            display:none;
        }
    </style>
</head>
<body>
       <div class="container my-5">
           <div class="row justify-content-center m-3">
            <div class="col-md-6">
               
         
            <div class="card">
  <div class="card-header bg-success text-white d-flex justify-content-between">
      <div >
      <?php echo e($todo->title); ?>

      </div>
      <?php if($todo->completed==true): ?>
      <div class="badge bg-success">
           completed
      </div>
      <?php endif; ?>

  </div>
  <div class="card-body">
    <p class="card-text">
        <?php echo e($todo->description); ?>

    </p>
    <a href="<?php echo e(url('edit',$todo->id)); ?>" class="btn btn-success">Edit</a>
    <a href="<?php echo e(url('delete',$todo->id)); ?>" class="btn btn-danger">Delete</a>

  </div>
</div>
<hr>
        
          
            </div>
           </div>
       </div>

       
</body>
</html><?php /**PATH C:\Users\Ridwanullah Raufi\Desktop\LaravelPractice\lvproject09\resources\views/Todo/viewTodo.blade.php ENDPATH**/ ?>