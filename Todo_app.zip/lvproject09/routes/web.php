<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\todosController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/





Route::get('/',[todosController::class,'index']);

Route::get('/todo',[todosController::class,'all'])->name('all-todos');

Route::get('view/{todo}',[todosController::class,'viewTodo']);


Route::get('edit/{todo}',[todosController::class,'edit']);

Route::post('edit/{todo}',[todosController::class,'update'])->name('update');

Route::get('delete/{todo}',[todosController::class,'delete']);

Route::get('addtoto',[todosController::class,'add_todo'])->name('addtodo');

Route::post('add-todos',[todosController::class,'add_todo_db'])->name('addnewtodo');