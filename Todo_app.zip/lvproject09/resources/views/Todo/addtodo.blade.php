<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{asset('assets/css/bootstrap.min.css')}}">
    <title>Edit</title>
   
</head>
<body>
       <div class="container my-5">
           <div class="row justify-content-center m-3">
            <div class="col-md-6">
               
                     <form action="{{route('addnewtodo')}}" method="post" class="">
                        @csrf
                          <div class="form-group">
                                <label for="" class="form-text fw-bold">Title</label>
                                <input type="text" name="title"  class="form-control bg-success text-white">
                          </div>
                          <div class="form-group">
                                <label for="" class="form-text fw-bold">Description</label>
                                <textarea name="description" class="form-control" cols="15" rows="7">
                               
                                </textarea>
                                
                          </div>

                          <div class="form-group">
                              <input type="submit" class="btn btn-success" value="Add">
                          </div>
                     </form>
       
          
            </div>
           </div>
       </div>

       
</body>
</html>