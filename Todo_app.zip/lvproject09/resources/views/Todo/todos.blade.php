<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{asset('assets/css/bootstrap.min.css')}}">
    <title>Document</title>
    <style>
        svg{
            display:none;
        }
        div.hidden{
            display:none;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="{{route('all-todos')}}">Todos</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
        <a class="nav-link" href="{{route('addtodo')}}">Create Todo</a>
        </li>
        
      
      </ul>
     
    </div>
  </div>
</nav>
       <div class="container my-5">
           <div class="row justify-content-center m-3">
            <div class="col-md-6">
                <h2 class="text-center">All Todos</h2>
            @foreach($todos as $todo)
            <div class="card">
  <div class="card-header d-flex text-white bg-success justify-content-between">
      <div>
      {{$todo->title}}
      </div>
      @if($todo->completed==true)
      <div class="badge bg-success">
           completed
      </div>
      @endif

  </div>
  <div class="card-body">
    <p class="card-text">
        {{$todo->description}}
    </p>
    <a href="{{url('view',$todo->id)}}" class="btn btn-success">View</a>
  </div>
</div>
<hr>
            @endforeach
            {{$todos->links()}}
            </div>
           </div>
       </div>

       
</body>
</html>