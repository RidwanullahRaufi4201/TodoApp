<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{asset('assets/css/bootstrap.min.css')}}">
    <title>Document</title>
    <style>
        svg{
            display:none;
        }
        div.hidden{
            display:none;
        }
    </style>
</head>
<body>
       <div class="container my-5">
           <div class="row justify-content-center m-3">
            <div class="col-md-6">
               
         
            <div class="card">
  <div class="card-header bg-success text-white d-flex justify-content-between">
      <div >
      {{$todo->title}}
      </div>
      @if($todo->completed==true)
      <div class="badge bg-success">
           completed
      </div>
      @endif

  </div>
  <div class="card-body">
    <p class="card-text">
        {{$todo->description}}
    </p>
    <a href="{{url('edit',$todo->id)}}" class="btn btn-success">Edit</a>
    <a href="{{url('delete',$todo->id)}}" class="btn btn-danger">Delete</a>

  </div>
</div>
<hr>
        
          
            </div>
           </div>
       </div>

       
</body>
</html>