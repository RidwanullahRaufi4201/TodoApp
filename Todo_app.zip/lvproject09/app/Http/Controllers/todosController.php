<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\Todo;
use lluminate\Database\Eloquent\Collection;
class todosController extends Controller
{
    public function index()
    {
        return view('Todo.index');
    }

    public function all()
    {
           $todos=Todo::paginate(3);
           return view('Todo.todos',['todos'=>$todos]);
    }


    public function viewTodo($id)
    {
           return view('Todo.viewTodo',['todo'=>Todo::find($id)]);
    }

    public function edit($id)
    {
              return view('Todo.edit',['todo'=>Todo::find($id)]);
              
    }
    public function update(Request $req,$id)
    {
               $req->validate([
                  'title'=>'required',
                  'description'=>'required',
               ]);
         $todo=Todo::find($id);
         $todo->title=$req->title;
         $todo->description=$req->description;
         $todo->save();

       return  redirect(route('all-todos'));

    }

    public function delete($id)
    {
             if(Todo::destroy($id))
             {
                return redirect(route('all-todos'));
             }
    }


    public function add_todo()
    {
        return view('Todo.addtodo');
    }

    public function add_todo_db(Request $req)
    {
        $req->validate([
            'title'=>'required',
            'description'=>'required',
         ]);
         $todo=new Todo();
         $todo->title=$req->title;
         $todo->description=$req->description;
         $todo->completed=false;
         $todo->save();

         return redirect(route('all-todos'));
    }
}
